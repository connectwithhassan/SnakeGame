import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Random;

public class SnakeGame extends JPanel implements KeyListener, ActionListener {

    private final int WIDTH = 400;
    private final int HEIGHT = 400;
    private final int UNIT_SIZE = 20;
    private final int DELAY = 100;

    private LinkedList<Point> snake;
    private Point food; // RANDOMLY SPAWNS FOOD ANYWHERE BY USING RANDOM FUNCTION
    private char direction = 'R'; // STARTING DIRECTION OF SNAKE IN WHICH R DENOTES RIGHT
    private boolean running = true; // CHECKING THE CONDITION IF STARTING POINT IS RIGHT THEN MOVE ELSE GAME OVER
    private Timer timer;

    public SnakeGame() {
        snake = new LinkedList<>();
        snake.add(new Point(0, 2));
        snake.add(new Point(0, 1));
        snake.add(new Point(0, 0));
        food = new Point(5, 5);

        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);

        timer = new Timer(DELAY, this);
        timer.start();
    }

    private void move() {
        Point head = snake.getFirst();
        Point newHead = (Point) head.clone();

        switch (direction) {
            case 'R':
                newHead.x++;
                break;
            case 'L':
                newHead.x--;
                break;
            case 'U':
                newHead.y--;
                break;
            case 'D':
                newHead.y++;
                break;
        }

        if (newHead.equals(food)) {
            snake.addFirst(newHead);
            generateFood();
        } else {
            snake.removeLast();
            if (snake.contains(newHead) || outOfBounds(newHead)) {
                running = false;
                timer.stop();
            } else {
                snake.addFirst(newHead);
            }
        }
    }

    private boolean outOfBounds(Point point) {
        return point.x < 0 || point.x >= WIDTH / UNIT_SIZE || point.y < 0 || point.y >= HEIGHT / UNIT_SIZE;
    }

    private void generateFood() {
        Random random = new Random();
        int x = random.nextInt(WIDTH / UNIT_SIZE);
        int y = random.nextInt(HEIGHT / UNIT_SIZE);
        food.setLocation(x, y);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    private void draw(Graphics g) {
        if (running) {
            g.setColor(Color.GREEN);
            for (Point point : snake) {
                g.fillRect(point.x * UNIT_SIZE, point.y * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
            }

            g.setColor(Color.RED);
            g.fillRect(food.x * UNIT_SIZE, food.y * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
        } else {
            gameOver(g);
        }
    }

    private void gameOver(Graphics g) {
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 40));
        FontMetrics metrics = getFontMetrics(g.getFont());
        g.drawString("Game Over", (WIDTH - metrics.stringWidth("Game Over")) / 2, HEIGHT / 2);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            move();
        }
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT && direction != 'R') {
            direction = 'L';
        } else if (key == KeyEvent.VK_RIGHT && direction != 'L') {
            direction = 'R';
        } else if (key == KeyEvent.VK_UP && direction != 'D') {
            direction = 'U';
        } else if (key == KeyEvent.VK_DOWN && direction != 'U') {
            direction = 'D';
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        SnakeGame game = new SnakeGame();
        frame.add(game);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
