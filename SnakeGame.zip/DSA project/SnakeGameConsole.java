import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class SnakeGameConsole {
    private static final int WIDTH = 20;
    private static final int HEIGHT = 10;
    private static final char EMPTY_CELL = '-';
    private static final char SNAKE_BODY = '#';
    private static final char FOOD_CELL = '*';

    private LinkedList<Point> snake;
    private Point food;
    private char[][] grid;
    private char direction;
    private boolean running;
    private Random random;

    public SnakeGameConsole() {
        snake = new LinkedList<>();
        snake.add(new Point(0, 0)); // initial position of snake
        direction = 'R'; // start moving right
        running = true;
        random = new Random();

        grid = new char[HEIGHT][WIDTH];
        initializeGrid();
        spawnFood();
    }

    private void initializeGrid() {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                grid[i][j] = EMPTY_CELL;
            }
        }
    }

    private void spawnFood() {
        int x = random.nextInt(WIDTH);
        int y = random.nextInt(HEIGHT);

        while (grid[y][x] != EMPTY_CELL) {
            x = random.nextInt(WIDTH);
            y = random.nextInt(HEIGHT);
        }

        food = new Point(x, y);
        grid[y][x] = FOOD_CELL;
    }

    private void move() {
        Point head = snake.getFirst();
        Point newHead = new Point(head.x, head.y);

        switch (direction) {
            case 'U':
                newHead.y--;
                break;
            case 'D':
                newHead.y++;
                break;
            case 'L':
                newHead.x--;
                break;
            case 'R':
                newHead.x++;
                break;
        }

        if (newHead.x < 0 || newHead.x >= WIDTH || newHead.y < 0 || newHead.y >= HEIGHT) {
            running = false;
            return;
        }

        if (newHead.equals(food)) {
            snake.addFirst(newHead);
            grid[newHead.y][newHead.x] = SNAKE_BODY;
            spawnFood();
        } else {
            Point tail = snake.removeLast();
            grid[tail.y][tail.x] = EMPTY_CELL;

            if (grid[newHead.y][newHead.x] == SNAKE_BODY) {
                running = false;
                return;
            }

            snake.addFirst(newHead);
            grid[newHead.y][newHead.x] = SNAKE_BODY;
        }
    }

    private void printGrid() {
        for (char[] row : grid) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);

        while (running) {
            printGrid();
            System.out.print("Enter direction (U/D/L/R): ");
            direction = scanner.nextLine().toUpperCase().charAt(0);

            move();
            System.out.println();
        }

        System.out.println("Game Over!");
        scanner.close();
    }

    public static void main(String[] args) {
        SnakeGameConsole game = new SnakeGameConsole();
        game.start();
    }

    private static class Point {
        int x, y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        boolean equals(Point other) {
            return this.x == other.x && this.y == other.y;
        }
    }
}
